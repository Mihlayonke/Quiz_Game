/********************************************************************************
** Form generated from reading UI file 'player2.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYER2_H
#define UI_PLAYER2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_player2
{
public:
    QGroupBox *groupBox;
    QGroupBox *groupBox_3;
    QPushButton *nextButton;
    QGroupBox *groupBox_2;
    QTextBrowser *nameText;
    QProgressBar *answerTime;
    QTextBrowser *quizText;
    QProgressBar *levelTime;
    QLabel *logo2;
    QLabel *oppLogo;
    QGroupBox *groupBox_4;
    QRadioButton *radioTrue;
    QRadioButton *radioFalse;

    void setupUi(QDialog *player2)
    {
        if (player2->objectName().isEmpty())
            player2->setObjectName(QString::fromUtf8("player2"));
        player2->resize(864, 512);
        player2->setSizeGripEnabled(true);
        player2->setModal(true);
        groupBox = new QGroupBox(player2);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(20, 20, 831, 491));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(40, 410, 711, 61));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        nextButton = new QPushButton(groupBox_3);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));
        nextButton->setGeometry(QRect(170, 20, 381, 31));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setItalic(true);
        font.setUnderline(true);
        font.setWeight(75);
        nextButton->setFont(font);
        nextButton->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(40, 10, 711, 351));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        nameText = new QTextBrowser(groupBox_2);
        nameText->setObjectName(QString::fromUtf8("nameText"));
        nameText->setGeometry(QRect(0, 220, 271, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MS UI Gothic"));
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        nameText->setFont(font1);
        answerTime = new QProgressBar(groupBox_2);
        answerTime->setObjectName(QString::fromUtf8("answerTime"));
        answerTime->setGeometry(QRect(270, 190, 441, 91));
        answerTime->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);"));
        answerTime->setValue(0);
        answerTime->setTextVisible(false);
        quizText = new QTextBrowser(groupBox_2);
        quizText->setObjectName(QString::fromUtf8("quizText"));
        quizText->setGeometry(QRect(0, 280, 711, 71));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        quizText->setFont(font2);
        quizText->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        levelTime = new QProgressBar(groupBox_2);
        levelTime->setObjectName(QString::fromUtf8("levelTime"));
        levelTime->setGeometry(QRect(300, 10, 351, 23));
        levelTime->setValue(0);
        levelTime->setTextVisible(false);
        logo2 = new QLabel(groupBox_2);
        logo2->setObjectName(QString::fromUtf8("logo2"));
        logo2->setGeometry(QRect(0, 30, 271, 191));
        oppLogo = new QLabel(groupBox_2);
        oppLogo->setObjectName(QString::fromUtf8("oppLogo"));
        oppLogo->setGeometry(QRect(530, 60, 181, 131));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(40, 360, 711, 51));
        groupBox_4->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        radioTrue = new QRadioButton(groupBox_4);
        radioTrue->setObjectName(QString::fromUtf8("radioTrue"));
        radioTrue->setGeometry(QRect(230, 10, 82, 31));
        QFont font3;
        font3.setBold(true);
        font3.setWeight(75);
        radioTrue->setFont(font3);
        radioTrue->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        radioFalse = new QRadioButton(groupBox_4);
        radioFalse->setObjectName(QString::fromUtf8("radioFalse"));
        radioFalse->setGeometry(QRect(370, 10, 82, 31));
        radioFalse->setFont(font3);
        radioFalse->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));

        retranslateUi(player2);

        QMetaObject::connectSlotsByName(player2);
    } // setupUi

    void retranslateUi(QDialog *player2)
    {
        player2->setWindowTitle(QCoreApplication::translate("player2", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("player2", "GroupBox", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("player2", "GroupBox", nullptr));
        nextButton->setText(QCoreApplication::translate("player2", "ANSWER", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("player2", "GroupBox", nullptr));
        logo2->setText(QString());
        oppLogo->setText(QString());
        groupBox_4->setTitle(QCoreApplication::translate("player2", "GroupBox", nullptr));
        radioTrue->setText(QCoreApplication::translate("player2", "True", nullptr));
        radioFalse->setText(QCoreApplication::translate("player2", "False", nullptr));
    } // retranslateUi

};

namespace Ui {
    class player2: public Ui_player2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYER2_H
