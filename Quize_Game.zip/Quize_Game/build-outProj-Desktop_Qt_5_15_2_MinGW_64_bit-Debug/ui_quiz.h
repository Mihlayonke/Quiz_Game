/********************************************************************************
** Form generated from reading UI file 'quiz.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUIZ_H
#define UI_QUIZ_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_quiz
{
public:
    QGroupBox *groupBox_3;
    QGroupBox *groupBox;
    QLabel *logo1;
    QProgressBar *bar1;
    QLabel *logo2;
    QProgressBar *bar2;
    QGroupBox *groupBox_2;
    QPushButton *quit;
    QTextBrowser *player1;
    QProgressBar *timeBar1;
    QProgressBar *timeBar3;
    QProgressBar *timeBar2;
    QTextBrowser *player2;
    QPushButton *quiz_2;
    QLabel *label;

    void setupUi(QDialog *quiz)
    {
        if (quiz->objectName().isEmpty())
            quiz->setObjectName(QString::fromUtf8("quiz"));
        quiz->resize(810, 685);
        quiz->setSizeGripEnabled(true);
        quiz->setModal(true);
        groupBox_3 = new QGroupBox(quiz);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(20, 20, 761, 601));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        groupBox = new QGroupBox(groupBox_3);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 20, 701, 361));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logo1 = new QLabel(groupBox);
        logo1->setObjectName(QString::fromUtf8("logo1"));
        logo1->setGeometry(QRect(60, 20, 251, 201));
        bar1 = new QProgressBar(groupBox);
        bar1->setObjectName(QString::fromUtf8("bar1"));
        bar1->setGeometry(QRect(70, 240, 551, 31));
        bar1->setStyleSheet(QString::fromUtf8("border-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));"));
        bar1->setValue(50);
        bar1->setTextVisible(false);
        logo2 = new QLabel(groupBox);
        logo2->setObjectName(QString::fromUtf8("logo2"));
        logo2->setGeometry(QRect(360, 20, 251, 201));
        bar2 = new QProgressBar(groupBox);
        bar2->setObjectName(QString::fromUtf8("bar2"));
        bar2->setGeometry(QRect(70, 270, 551, 31));
        bar2->setLayoutDirection(Qt::RightToLeft);
        bar2->setStyleSheet(QString::fromUtf8("border-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(0, 0, 0, 0), stop:0.52 rgba(0, 0, 0, 0), stop:0.565 rgba(82, 121, 76, 33), stop:0.65 rgba(159, 235, 148, 64), stop:0.721925 rgba(255, 238, 150, 129), stop:0.77 rgba(255, 128, 128, 204), stop:0.89 rgba(191, 128, 255, 64), stop:1 rgba(0, 0, 0, 0));"));
        bar2->setValue(50);
        bar2->setTextVisible(false);
        groupBox_2 = new QGroupBox(groupBox_3);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(30, 390, 701, 191));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        quit = new QPushButton(groupBox_2);
        quit->setObjectName(QString::fromUtf8("quit"));
        quit->setGeometry(QRect(300, 170, 81, 21));
        QFont font;
        font.setPointSize(12);
        font.setItalic(true);
        font.setStrikeOut(false);
        quit->setFont(font);
        quit->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(245, 224, 176, 255), stop:0.09 rgba(246, 189, 237, 255), stop:0.14 rgba(194, 207, 246, 255), stop:0.19 rgba(184, 160, 168, 255), stop:0.25 rgba(171, 186, 248, 255), stop:0.32 rgba(243, 248, 224, 255), stop:0.385 rgba(249, 162, 183, 255), stop:0.47 rgba(100, 115, 124, 255), stop:0.58 rgba(251, 205, 202, 255), stop:0.65 rgba(170, 128, 185, 255), stop:0.75 rgba(252, 222, 204, 255), stop:0.805 rgba(206, 122, 218, 255), stop:0.86 rgba(254, 223, 175, 255), stop:0.91 rgba(254, 236, 244, 255), stop:1 rgba(255, 191, 221, 255));"));
        player1 = new QTextBrowser(groupBox_2);
        player1->setObjectName(QString::fromUtf8("player1"));
        player1->setGeometry(QRect(50, 10, 231, 81));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Agency FB"));
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        player1->setFont(font1);
        player1->setStyleSheet(QString::fromUtf8("border-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(0, 0, 0, 255), stop:0.33 rgba(0, 0, 0, 255), stop:0.34 rgba(255, 30, 30, 255), stop:0.66 rgba(255, 0, 0, 255), stop:0.67 rgba(255, 255, 0, 255), stop:1 rgba(255, 255, 0, 255));"));
        timeBar1 = new QProgressBar(groupBox_2);
        timeBar1->setObjectName(QString::fromUtf8("timeBar1"));
        timeBar1->setGeometry(QRect(290, 10, 101, 16));
        timeBar1->setStyleSheet(QString::fromUtf8("border-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));\n"
"border-left-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        timeBar1->setTextVisible(false);
        timeBar3 = new QProgressBar(groupBox_2);
        timeBar3->setObjectName(QString::fromUtf8("timeBar3"));
        timeBar3->setGeometry(QRect(290, 50, 101, 20));
        timeBar3->setStyleSheet(QString::fromUtf8("border-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"));
        timeBar3->setValue(0);
        timeBar3->setTextVisible(false);
        timeBar2 = new QProgressBar(groupBox_2);
        timeBar2->setObjectName(QString::fromUtf8("timeBar2"));
        timeBar2->setGeometry(QRect(290, 30, 101, 16));
        timeBar2->setStyleSheet(QString::fromUtf8("border-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"));
        timeBar2->setValue(0);
        timeBar2->setTextVisible(false);
        player2 = new QTextBrowser(groupBox_2);
        player2->setObjectName(QString::fromUtf8("player2"));
        player2->setGeometry(QRect(400, 10, 231, 81));
        player2->setFont(font1);
        player2->setStyleSheet(QString::fromUtf8("border-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"));
        quiz_2 = new QPushButton(groupBox_2);
        quiz_2->setObjectName(QString::fromUtf8("quiz_2"));
        quiz_2->setGeometry(QRect(280, 100, 121, 51));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        quiz_2->setFont(font2);
        quiz_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(245, 224, 176, 255), stop:0.09 rgba(246, 189, 237, 255), stop:0.14 rgba(194, 207, 246, 255), stop:0.19 rgba(184, 160, 168, 255), stop:0.25 rgba(171, 186, 248, 255), stop:0.32 rgba(243, 248, 224, 255), stop:0.385 rgba(249, 162, 183, 255), stop:0.47 rgba(100, 115, 124, 255), stop:0.58 rgba(251, 205, 202, 255), stop:0.65 rgba(170, 128, 185, 255), stop:0.75 rgba(252, 222, 204, 255), stop:0.805 rgba(206, 122, 218, 255), stop:0.86 rgba(254, 223, 175, 255), stop:0.91 rgba(254, 236, 244, 255), stop:1 rgba(255, 191, 221, 255));"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(310, 70, 51, 20));
        QFont font3;
        font3.setPointSize(7);
        font3.setBold(true);
        font3.setWeight(75);
        label->setFont(font3);

        retranslateUi(quiz);

        QMetaObject::connectSlotsByName(quiz);
    } // setupUi

    void retranslateUi(QDialog *quiz)
    {
        quiz->setWindowTitle(QCoreApplication::translate("quiz", "Dialog", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("quiz", "GroupBox", nullptr));
        groupBox->setTitle(QCoreApplication::translate("quiz", "GroupBox", nullptr));
        logo1->setText(QString());
        logo2->setText(QString());
        groupBox_2->setTitle(QCoreApplication::translate("quiz", "GroupBox", nullptr));
        quit->setText(QCoreApplication::translate("quiz", "QUIT", nullptr));
        quiz_2->setText(QCoreApplication::translate("quiz", "GET QUIZ", nullptr));
        label->setText(QCoreApplication::translate("quiz", "level time", nullptr));
    } // retranslateUi

};

namespace Ui {
    class quiz: public Ui_quiz {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUIZ_H
