/********************************************************************************
** Form generated from reading UI file 'newgame.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWGAME_H
#define UI_NEWGAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_newgame
{
public:
    QGroupBox *groupBox_3;
    QGroupBox *player1Box;
    QLineEdit *player1Reg;
    QLabel *label;
    QRadioButton *ukzn1;
    QRadioButton *uj1;
    QRadioButton *uct1;
    QRadioButton *wits1;
    QRadioButton *mut1;
    QRadioButton *stellenbosch1;
    QRadioButton *dut1;
    QRadioButton *limpopo1;
    QRadioButton *up1;
    QRadioButton *unisa1;
    QGroupBox *player2Box;
    QLabel *label_2;
    QLineEdit *player2Reg;
    QRadioButton *ukzn2;
    QRadioButton *uj2;
    QRadioButton *uct2;
    QRadioButton *wits2;
    QRadioButton *mut2;
    QRadioButton *stellenbosch2;
    QRadioButton *dut2;
    QRadioButton *limpopo2;
    QRadioButton *unisa2;
    QRadioButton *up2;
    QPushButton *back;
    QPushButton *start;

    void setupUi(QDialog *newgame)
    {
        if (newgame->objectName().isEmpty())
            newgame->setObjectName(QString::fromUtf8("newgame"));
        newgame->resize(736, 404);
        newgame->setSizeGripEnabled(true);
        newgame->setModal(true);
        groupBox_3 = new QGroupBox(newgame);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(30, 20, 641, 371));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0, cy:0, angle:135, stop:0 rgba(255, 255, 0, 69), stop:0.375 rgba(255, 255, 0, 69), stop:0.423533 rgba(251, 255, 0, 145), stop:0.45 rgba(247, 255, 0, 208), stop:0.477581 rgba(255, 244, 71, 130), stop:0.518717 rgba(255, 218, 71, 130), stop:0.55 rgba(255, 255, 0, 255), stop:0.57754 rgba(255, 203, 0, 130), stop:0.625 rgba(255, 255, 0, 69), stop:1 rgba(255, 255, 0, 69));"));
        player1Box = new QGroupBox(groupBox_3);
        player1Box->setObjectName(QString::fromUtf8("player1Box"));
        player1Box->setGeometry(QRect(20, 20, 311, 261));
        player1Box->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        player1Reg = new QLineEdit(player1Box);
        player1Reg->setObjectName(QString::fromUtf8("player1Reg"));
        player1Reg->setGeometry(QRect(40, 60, 201, 51));
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        player1Reg->setFont(font);
        label = new QLabel(player1Box);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 10, 171, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MS Serif"));
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        label->setFont(font1);
        ukzn1 = new QRadioButton(player1Box);
        ukzn1->setObjectName(QString::fromUtf8("ukzn1"));
        ukzn1->setGeometry(QRect(40, 120, 82, 17));
        uj1 = new QRadioButton(player1Box);
        uj1->setObjectName(QString::fromUtf8("uj1"));
        uj1->setGeometry(QRect(40, 140, 82, 17));
        uct1 = new QRadioButton(player1Box);
        uct1->setObjectName(QString::fromUtf8("uct1"));
        uct1->setGeometry(QRect(40, 160, 82, 17));
        wits1 = new QRadioButton(player1Box);
        wits1->setObjectName(QString::fromUtf8("wits1"));
        wits1->setGeometry(QRect(40, 180, 82, 17));
        mut1 = new QRadioButton(player1Box);
        mut1->setObjectName(QString::fromUtf8("mut1"));
        mut1->setGeometry(QRect(140, 120, 82, 17));
        stellenbosch1 = new QRadioButton(player1Box);
        stellenbosch1->setObjectName(QString::fromUtf8("stellenbosch1"));
        stellenbosch1->setGeometry(QRect(140, 140, 82, 17));
        dut1 = new QRadioButton(player1Box);
        dut1->setObjectName(QString::fromUtf8("dut1"));
        dut1->setGeometry(QRect(140, 160, 82, 17));
        limpopo1 = new QRadioButton(player1Box);
        limpopo1->setObjectName(QString::fromUtf8("limpopo1"));
        limpopo1->setGeometry(QRect(140, 180, 82, 17));
        up1 = new QRadioButton(player1Box);
        up1->setObjectName(QString::fromUtf8("up1"));
        up1->setGeometry(QRect(40, 200, 82, 17));
        unisa1 = new QRadioButton(player1Box);
        unisa1->setObjectName(QString::fromUtf8("unisa1"));
        unisa1->setGeometry(QRect(140, 200, 82, 17));
        player2Box = new QGroupBox(groupBox_3);
        player2Box->setObjectName(QString::fromUtf8("player2Box"));
        player2Box->setGeometry(QRect(330, 20, 291, 261));
        player2Box->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        label_2 = new QLabel(player2Box);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 20, 171, 31));
        label_2->setFont(font1);
        player2Reg = new QLineEdit(player2Box);
        player2Reg->setObjectName(QString::fromUtf8("player2Reg"));
        player2Reg->setGeometry(QRect(20, 60, 201, 51));
        player2Reg->setFont(font);
        ukzn2 = new QRadioButton(player2Box);
        ukzn2->setObjectName(QString::fromUtf8("ukzn2"));
        ukzn2->setGeometry(QRect(20, 120, 82, 17));
        uj2 = new QRadioButton(player2Box);
        uj2->setObjectName(QString::fromUtf8("uj2"));
        uj2->setGeometry(QRect(20, 140, 82, 17));
        uct2 = new QRadioButton(player2Box);
        uct2->setObjectName(QString::fromUtf8("uct2"));
        uct2->setGeometry(QRect(20, 160, 82, 17));
        wits2 = new QRadioButton(player2Box);
        wits2->setObjectName(QString::fromUtf8("wits2"));
        wits2->setGeometry(QRect(20, 180, 82, 17));
        mut2 = new QRadioButton(player2Box);
        mut2->setObjectName(QString::fromUtf8("mut2"));
        mut2->setGeometry(QRect(140, 120, 82, 17));
        stellenbosch2 = new QRadioButton(player2Box);
        stellenbosch2->setObjectName(QString::fromUtf8("stellenbosch2"));
        stellenbosch2->setGeometry(QRect(140, 140, 82, 17));
        dut2 = new QRadioButton(player2Box);
        dut2->setObjectName(QString::fromUtf8("dut2"));
        dut2->setGeometry(QRect(140, 160, 82, 17));
        limpopo2 = new QRadioButton(player2Box);
        limpopo2->setObjectName(QString::fromUtf8("limpopo2"));
        limpopo2->setGeometry(QRect(140, 180, 82, 17));
        unisa2 = new QRadioButton(player2Box);
        unisa2->setObjectName(QString::fromUtf8("unisa2"));
        unisa2->setGeometry(QRect(140, 200, 82, 17));
        up2 = new QRadioButton(player2Box);
        up2->setObjectName(QString::fromUtf8("up2"));
        up2->setGeometry(QRect(20, 200, 82, 17));
        back = new QPushButton(groupBox_3);
        back->setObjectName(QString::fromUtf8("back"));
        back->setGeometry(QRect(150, 300, 181, 41));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        back->setFont(font2);
        back->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        start = new QPushButton(groupBox_3);
        start->setObjectName(QString::fromUtf8("start"));
        start->setGeometry(QRect(330, 300, 181, 41));
        start->setFont(font2);
        start->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));

        retranslateUi(newgame);

        QMetaObject::connectSlotsByName(newgame);
    } // setupUi

    void retranslateUi(QDialog *newgame)
    {
        newgame->setWindowTitle(QCoreApplication::translate("newgame", "Dialog", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("newgame", "GroupBox", nullptr));
        player1Box->setTitle(QCoreApplication::translate("newgame", "player1 reg...", nullptr));
        label->setText(QCoreApplication::translate("newgame", "PLAYER 1 name", nullptr));
        ukzn1->setText(QCoreApplication::translate("newgame", "ukzn", nullptr));
        uj1->setText(QCoreApplication::translate("newgame", "uj", nullptr));
        uct1->setText(QCoreApplication::translate("newgame", "uct", nullptr));
        wits1->setText(QCoreApplication::translate("newgame", "wits", nullptr));
        mut1->setText(QCoreApplication::translate("newgame", "mut", nullptr));
        stellenbosch1->setText(QCoreApplication::translate("newgame", "stellenbosch", nullptr));
        dut1->setText(QCoreApplication::translate("newgame", "dut", nullptr));
        limpopo1->setText(QCoreApplication::translate("newgame", "limpopo", nullptr));
        up1->setText(QCoreApplication::translate("newgame", "up", nullptr));
        unisa1->setText(QCoreApplication::translate("newgame", "unisa", nullptr));
        player2Box->setTitle(QCoreApplication::translate("newgame", "player2 reg...", nullptr));
        label_2->setText(QCoreApplication::translate("newgame", "PLAYER 2 name", nullptr));
        ukzn2->setText(QCoreApplication::translate("newgame", "ukzn", nullptr));
        uj2->setText(QCoreApplication::translate("newgame", "uj", nullptr));
        uct2->setText(QCoreApplication::translate("newgame", "uct", nullptr));
        wits2->setText(QCoreApplication::translate("newgame", "wits", nullptr));
        mut2->setText(QCoreApplication::translate("newgame", "mut", nullptr));
        stellenbosch2->setText(QCoreApplication::translate("newgame", "stellenbosch", nullptr));
        dut2->setText(QCoreApplication::translate("newgame", "dut", nullptr));
        limpopo2->setText(QCoreApplication::translate("newgame", "limpopo", nullptr));
        unisa2->setText(QCoreApplication::translate("newgame", "unisa", nullptr));
        up2->setText(QCoreApplication::translate("newgame", "up", nullptr));
        back->setText(QCoreApplication::translate("newgame", "BACK", nullptr));
        start->setText(QCoreApplication::translate("newgame", "START", nullptr));
    } // retranslateUi

};

namespace Ui {
    class newgame: public Ui_newgame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWGAME_H
