/********************************************************************************
** Form generated from reading UI file 'leveltwo2.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LEVELTWO2_H
#define UI_LEVELTWO2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_leveltwo2
{
public:
    QGroupBox *groupBox;
    QGroupBox *groupBox_3;
    QPushButton *pushButton;
    QGroupBox *groupBox_2;
    QTextBrowser *nameText;
    QProgressBar *answerTime;
    QProgressBar *levelTime;
    QLabel *logo2;
    QLabel *oppLogo;
    QGroupBox *groupBox_4;
    QTextBrowser *textBrowser;
    QTextBrowser *optA;
    QTextBrowser *optB;
    QTextBrowser *optC;
    QTextBrowser *optD;
    QRadioButton *RadioA;
    QRadioButton *RadioB;
    QRadioButton *RadioC;
    QRadioButton *RadioD;

    void setupUi(QDialog *leveltwo2)
    {
        if (leveltwo2->objectName().isEmpty())
            leveltwo2->setObjectName(QString::fromUtf8("leveltwo2"));
        leveltwo2->resize(888, 672);
        leveltwo2->setSizeGripEnabled(true);
        leveltwo2->setModal(false);
        groupBox = new QGroupBox(leveltwo2);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(20, 0, 831, 651));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(40, 530, 711, 71));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));\n"
"border-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, "
                        "255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        pushButton = new QPushButton(groupBox_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(210, 10, 341, 41));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setItalic(true);
        font.setUnderline(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(40, 10, 711, 281));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        nameText = new QTextBrowser(groupBox_2);
        nameText->setObjectName(QString::fromUtf8("nameText"));
        nameText->setGeometry(QRect(0, 220, 291, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MS UI Gothic"));
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        nameText->setFont(font1);
        answerTime = new QProgressBar(groupBox_2);
        answerTime->setObjectName(QString::fromUtf8("answerTime"));
        answerTime->setGeometry(QRect(290, 200, 421, 81));
        answerTime->setValue(0);
        answerTime->setTextVisible(false);
        levelTime = new QProgressBar(groupBox_2);
        levelTime->setObjectName(QString::fromUtf8("levelTime"));
        levelTime->setGeometry(QRect(300, 10, 351, 23));
        levelTime->setValue(0);
        levelTime->setTextVisible(false);
        logo2 = new QLabel(groupBox_2);
        logo2->setObjectName(QString::fromUtf8("logo2"));
        logo2->setGeometry(QRect(0, 20, 291, 201));
        oppLogo = new QLabel(groupBox_2);
        oppLogo->setObjectName(QString::fromUtf8("oppLogo"));
        oppLogo->setGeometry(QRect(510, 50, 201, 151));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(40, 290, 711, 241));
        groupBox_4->setStyleSheet(QString::fromUtf8("border-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        textBrowser = new QTextBrowser(groupBox_4);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(0, 0, 711, 101));
        textBrowser->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        optA = new QTextBrowser(groupBox_4);
        optA->setObjectName(QString::fromUtf8("optA"));
        optA->setGeometry(QRect(80, 120, 261, 51));
        optA->setStyleSheet(QString::fromUtf8(""));
        optB = new QTextBrowser(groupBox_4);
        optB->setObjectName(QString::fromUtf8("optB"));
        optB->setGeometry(QRect(80, 170, 261, 51));
        optC = new QTextBrowser(groupBox_4);
        optC->setObjectName(QString::fromUtf8("optC"));
        optC->setGeometry(QRect(430, 120, 261, 51));
        optD = new QTextBrowser(groupBox_4);
        optD->setObjectName(QString::fromUtf8("optD"));
        optD->setGeometry(QRect(430, 170, 261, 51));
        RadioA = new QRadioButton(groupBox_4);
        RadioA->setObjectName(QString::fromUtf8("RadioA"));
        RadioA->setGeometry(QRect(50, 120, 31, 51));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        RadioA->setFont(font2);
        RadioA->setLayoutDirection(Qt::RightToLeft);
        RadioB = new QRadioButton(groupBox_4);
        RadioB->setObjectName(QString::fromUtf8("RadioB"));
        RadioB->setGeometry(QRect(50, 170, 31, 51));
        RadioB->setFont(font2);
        RadioB->setLayoutDirection(Qt::RightToLeft);
        RadioC = new QRadioButton(groupBox_4);
        RadioC->setObjectName(QString::fromUtf8("RadioC"));
        RadioC->setGeometry(QRect(400, 120, 31, 51));
        RadioC->setFont(font2);
        RadioC->setLayoutDirection(Qt::RightToLeft);
        RadioD = new QRadioButton(groupBox_4);
        RadioD->setObjectName(QString::fromUtf8("RadioD"));
        RadioD->setGeometry(QRect(400, 170, 31, 51));
        RadioD->setFont(font2);
        RadioD->setLayoutDirection(Qt::RightToLeft);

        retranslateUi(leveltwo2);

        QMetaObject::connectSlotsByName(leveltwo2);
    } // setupUi

    void retranslateUi(QDialog *leveltwo2)
    {
        leveltwo2->setWindowTitle(QCoreApplication::translate("leveltwo2", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("leveltwo2", "GroupBox", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("leveltwo2", "GroupBox", nullptr));
        pushButton->setText(QCoreApplication::translate("leveltwo2", "ANSWER", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("leveltwo2", "GroupBox", nullptr));
        logo2->setText(QString());
        oppLogo->setText(QString());
        groupBox_4->setTitle(QString());
        RadioA->setText(QCoreApplication::translate("leveltwo2", "A", nullptr));
        RadioB->setText(QCoreApplication::translate("leveltwo2", "B", nullptr));
        RadioC->setText(QCoreApplication::translate("leveltwo2", "C", nullptr));
        RadioD->setText(QCoreApplication::translate("leveltwo2", "D", nullptr));
    } // retranslateUi

};

namespace Ui {
    class leveltwo2: public Ui_leveltwo2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LEVELTWO2_H
