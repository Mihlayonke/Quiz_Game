/********************************************************************************
** Form generated from reading UI file 'player1.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYER1_H
#define UI_PLAYER1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_player1
{
public:
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QTextBrowser *nameText;
    QTextBrowser *quizText;
    QProgressBar *levelTime;
    QProgressBar *answerTime;
    QLabel *logo1;
    QLabel *oppLogo;
    QGroupBox *groupBox_3;
    QRadioButton *radioTrue;
    QRadioButton *radioFalse;
    QGroupBox *groupBox_4;
    QPushButton *nextButton;

    void setupUi(QDialog *player1)
    {
        if (player1->objectName().isEmpty())
            player1->setObjectName(QString::fromUtf8("player1"));
        player1->resize(831, 563);
        player1->setSizeGripEnabled(true);
        player1->setModal(true);
        groupBox = new QGroupBox(player1);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(50, 10, 741, 521));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 20, 711, 361));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        nameText = new QTextBrowser(groupBox_2);
        nameText->setObjectName(QString::fromUtf8("nameText"));
        nameText->setGeometry(QRect(430, 220, 281, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("MS UI Gothic"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        nameText->setFont(font);
        nameText->setFrameShape(QFrame::StyledPanel);
        quizText = new QTextBrowser(groupBox_2);
        quizText->setObjectName(QString::fromUtf8("quizText"));
        quizText->setGeometry(QRect(0, 280, 711, 81));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        quizText->setFont(font1);
        quizText->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        levelTime = new QProgressBar(groupBox_2);
        levelTime->setObjectName(QString::fromUtf8("levelTime"));
        levelTime->setGeometry(QRect(60, 10, 361, 23));
        levelTime->setValue(0);
        levelTime->setTextVisible(false);
        answerTime = new QProgressBar(groupBox_2);
        answerTime->setObjectName(QString::fromUtf8("answerTime"));
        answerTime->setGeometry(QRect(0, 190, 431, 91));
        answerTime->setLayoutDirection(Qt::RightToLeft);
        answerTime->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);"));
        answerTime->setValue(0);
        answerTime->setTextVisible(false);
        logo1 = new QLabel(groupBox_2);
        logo1->setObjectName(QString::fromUtf8("logo1"));
        logo1->setGeometry(QRect(430, 20, 281, 201));
        oppLogo = new QLabel(groupBox_2);
        oppLogo->setObjectName(QString::fromUtf8("oppLogo"));
        oppLogo->setGeometry(QRect(0, 60, 161, 131));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 380, 711, 51));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        radioTrue = new QRadioButton(groupBox_3);
        radioTrue->setObjectName(QString::fromUtf8("radioTrue"));
        radioTrue->setGeometry(QRect(240, 10, 82, 31));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        radioTrue->setFont(font2);
        radioTrue->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        radioFalse = new QRadioButton(groupBox_3);
        radioFalse->setObjectName(QString::fromUtf8("radioFalse"));
        radioFalse->setGeometry(QRect(370, 10, 82, 31));
        radioFalse->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 430, 711, 61));
        groupBox_4->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        nextButton = new QPushButton(groupBox_4);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));
        nextButton->setGeometry(QRect(170, 20, 371, 31));
        QFont font3;
        font3.setPointSize(11);
        font3.setBold(true);
        font3.setItalic(true);
        font3.setUnderline(true);
        font3.setWeight(75);
        nextButton->setFont(font3);
        nextButton->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 178, 102, 255), stop:0.55 rgba(235, 148, 61, 255), stop:0.98 rgba(0, 0, 0, 255), stop:1 rgba(0, 0, 0, 0));"));

        retranslateUi(player1);

        QMetaObject::connectSlotsByName(player1);
    } // setupUi

    void retranslateUi(QDialog *player1)
    {
        player1->setWindowTitle(QCoreApplication::translate("player1", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("player1", "GroupBox", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("player1", "GroupBox", nullptr));
        logo1->setText(QString());
        oppLogo->setText(QString());
        groupBox_3->setTitle(QCoreApplication::translate("player1", "GroupBox", nullptr));
        radioTrue->setText(QCoreApplication::translate("player1", "True", nullptr));
        radioFalse->setText(QCoreApplication::translate("player1", "False", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("player1", "GroupBox", nullptr));
        nextButton->setText(QCoreApplication::translate("player1", "ANSWER", nullptr));
    } // retranslateUi

};

namespace Ui {
    class player1: public Ui_player1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYER1_H
