#include "newgame.h"
#include "ui_newgame.h"

#include "QButtonGroup"
#include "QMessageBox"
#include "quiz.h"

newgame::newgame(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::newgame)
{
    ui->setupUi(this);
    active=true;
}

newgame::~newgame()
{
    delete ui;
}

void newgame::on_start_clicked()
{
    QMessageBox msg;
    QString logo1,logo2;
    quiz Q;

    //player 1 school
    if(ui->ukzn1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\ukzn.png";
    }
    else if(ui->uj1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\uj.pngg";
    }
    else if(ui->wits1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\wits.png";
    }
    else if(ui->uct1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\uct.png";
    }
    else if(ui->up1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\up.png";
    }
    else if(ui->mut1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\mut.png";
    }
    else if(ui->stellenbosch1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\stellenbosch.png";
    }
    else if(ui->dut1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\dut.png";
    }
    else if(ui->limpopo1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\limpopo.png";
    }
    else if(ui->unisa1->isChecked()){
        logo1="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\unisa.png";
    }

//player 2 school
    if(ui->ukzn2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\ukzn.png";
    }
    else if(ui->uj2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\uj.png";
    }
    else if(ui->wits2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\wits.png";
    }
    else if(ui->uct2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\uct.png";
    }
    else if(ui->up2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\up.png";
    }
    else if(ui->mut2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\mut.png";
    }
    else if(ui->stellenbosch2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\stellenbosch.png";
    }
    else if(ui->dut2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\dut.png";
    }
    else if(ui->limpopo2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\limpopo.png";
    }
    else if(ui->unisa2->isChecked()){
        logo2="C:\\Users\\Afri Soul\\Music\\outProj\\outProj\\Pics\\unisa.png";
    }


    //checking that everything is selected
    if(ui->player1Reg->text()==nullptr){
        msg.setText("NO NAME FOR PLAYER 1");
        msg.exec();
    }
    else if(ui->player2Reg->text()==nullptr){
        msg.setText("NO NAME FOR PLAYER 2");
        msg.exec();
    }
    else if(logo1==nullptr){
        msg.setText("NO SCHOOL FOR PLAYER 1");
        msg.exec();
    }
    else if(logo2==nullptr){
        msg.setText("NO SCHOOL FOR PLAYER 2");
        msg.exec();
    }

    //if all is reg then start
    else if(ui->player1Reg->text()!=nullptr&&ui->player2Reg->text()!=nullptr&&
            logo1!=nullptr&&logo2!=nullptr){
        Q.setPlayer1(ui->player1Reg->text());
        Q.setPlayer2(ui->player2Reg->text());

        Q.setLogo1(logo1);
        Q.setLogo2(logo2);

        Q.exec();
        this->hide();
    }


}

void newgame::on_back_clicked()
{
    this->hide();
    active=false;

}

