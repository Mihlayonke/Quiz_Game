#include "player1.h"
#include "ui_player1.h"

#include "QPixmap"
#include "newgame.h"

player1::player1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::player1)
{
    ui->setupUi(this);

    //add pic edit to manupulate choice of logo/university
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(timeUp()));
    timer->start(1000);
}

player1::~player1()
{
    delete ui;
}

void player1::setName(QString name,QString logoPlayer)
{
    ui->nameText->setText(name);
    QString picPath=logoPlayer;
    QPixmap pix=picPath;
    int w=ui->logo1->width();
    int h=ui->logo1->height();
    ui->logo1->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}

void player1::setOpp(QString logoOpp)
{
    QString opponent=logoOpp;
    QPixmap opp=opponent;
    int w2=ui->oppLogo->width();
    int h2=ui->oppLogo->height();
    ui->oppLogo->setPixmap(opp.scaled(w2,h2,Qt::KeepAspectRatio));
}


void player1::on_answerTime_valueChanged(int value)
{
    ui->answerTime->setValue(value);

}

void player1::timeUp()
{
    on_answerTime_valueChanged(num);
    num+=10;//chang1  3-chang1 in all
    if(num==100){//chang1
        num=0;
        this->hide();
    }
}

void player1::on_nextButton_clicked()
{
    this->hide();
}


void player1::on_pushButton_2_clicked()
{
    newgame ng;
    ng.exec();
    this->close();
}

