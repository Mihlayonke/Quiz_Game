#include "player2.h"
#include "ui_player2.h"

#include "QPixmap"
#include "newgame.h"

player2::player2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::player2)
{
    ui->setupUi(this);

    //add pic edit to manupulate choice of logo/university




    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(timeUp()));
    timer->start(1000);
}

player2::~player2()
{
    delete ui;
}

void player2::on_answerTime_valueChanged(int value)
{
    ui->answerTime->setValue(value);
}

void player2::setName(QString name,QString logoPlayer)
{
    ui->nameText->setText(name);
    QString picPath=logoPlayer;
    QPixmap pix=picPath;
    int w=ui->logo2->width();
    int h=ui->logo2->height();
    ui->logo2->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}

void player2::setOpp(QString logoOpp)
{
    QString opponent=logoOpp;
    QPixmap opp=opponent;
    int w2=ui->oppLogo->width();
    int h2=ui->oppLogo->height();
    ui->oppLogo->setPixmap(opp.scaled(w2,h2,Qt::KeepAspectRatio));

}

void player2::timeUp()
{
    on_answerTime_valueChanged(num);
    num+=10;
    if(num==100){
        num=0;
        this->hide();
    }
}



void player2::on_nextButton_clicked()
{
    this->close();
}


void player2::on_pushButton_2_clicked()
{
    newgame ng;
    ng.exec();
    this->close();
}

