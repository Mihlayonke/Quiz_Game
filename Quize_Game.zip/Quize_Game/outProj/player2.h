#ifndef PLAYER2_H
#define PLAYER2_H

#include "QTimer"

#include <QDialog>

namespace Ui {
class player2;
}

class player2 : public QDialog
{
    Q_OBJECT

public:
    explicit player2(QWidget *parent = nullptr);
    ~player2();


    void setName(QString name,QString logoPLayer);
    void setOpp(QString logoOpp);
private slots:
    void on_answerTime_valueChanged(int value);

    void timeUp();

    void on_nextButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::player2 *ui;
    QTimer* timer;

    int num=0;
};

#endif // PLAYER2_H
