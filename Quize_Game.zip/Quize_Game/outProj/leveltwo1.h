#ifndef LEVELTWO1_H
#define LEVELTWO1_H

#include "QTimer"

#include <QDialog>

namespace Ui {
class levelTwo1;
}

class levelTwo1 : public QDialog
{
    Q_OBJECT

public:
    explicit levelTwo1(QWidget *parent = nullptr);
    ~levelTwo1();

    void setName(QString name,QString logoPlayer);
    void setOpp(QString logoOpp);
private slots:
    void on_answerTime_valueChanged(int value);

    void timeUp();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::levelTwo1 *ui;
    QTimer* timer;
    int num=0;//chang1
};

#endif // LEVELTWO1_H
