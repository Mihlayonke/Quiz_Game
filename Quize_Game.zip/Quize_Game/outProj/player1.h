#ifndef PLAYER1_H
#define PLAYER1_H

#include "QTimer"
#include <QDialog>

namespace Ui {
class player1;
}

class player1 : public QDialog
{
    Q_OBJECT

public:
    explicit player1(QWidget *parent = nullptr);
    ~player1();
    void setName(QString name,QString logoPlayer);
    void setOpp(QString logoOpp);

private slots:
    void on_answerTime_valueChanged(int value);

    void timeUp();

    void on_nextButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::player1 *ui;
    QTimer* timer;
    int num=0;//chang1
};

#endif // PLAYER1_H
