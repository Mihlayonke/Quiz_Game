#include "leveltwo1.h"
#include "ui_leveltwo1.h"

#include "newgame.h"

levelTwo1::levelTwo1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::levelTwo1)
{
    ui->setupUi(this);

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(timeUp()));
    timer->start(1000);


}

levelTwo1::~levelTwo1()
{
    delete ui;
}

void levelTwo1::setName(QString name,QString logoPlayer)
{
    ui->nameText->setText(name);
    QString picPath=logoPlayer;
    QPixmap pix=picPath;
    int w=ui->logo1->width();
    int h=ui->logo1->height();
    ui->logo1->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}

void levelTwo1::setOpp(QString logoOpp)
{
    QString opponent=logoOpp;
    QPixmap opp=opponent;
    int w2=ui->oppLogo->width();
    int h2=ui->oppLogo->height();
    ui->oppLogo->setPixmap(opp.scaled(w2,h2,Qt::KeepAspectRatio));
}


void levelTwo1::on_answerTime_valueChanged(int value)
{
    ui->answerTime->setValue(value);

}

void levelTwo1::timeUp()
{
    on_answerTime_valueChanged(num);
    num+=10;//chang1  3-chang1 in all
    if(num==100){//chang1
        num=0;
        this->hide();
    }
}

void levelTwo1::on_pushButton_clicked()
{
    this->hide();
}


void levelTwo1::on_pushButton_2_clicked()
{
    newgame ng;
    ng.exec();
    this->close();
}

