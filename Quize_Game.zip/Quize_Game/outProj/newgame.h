#ifndef NEWGAME_H
#define NEWGAME_H

#include <QDialog>

namespace Ui {
class newgame;
}

class newgame : public QDialog
{
    Q_OBJECT

public:
    explicit newgame(QWidget *parent = nullptr);
    ~newgame();

private slots:
    void on_start_clicked();

    void on_back_clicked();

private:
    Ui::newgame *ui;
    bool active;
};

#endif // NEWGAME_H
