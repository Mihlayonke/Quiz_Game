#ifndef QUIZ_H
#define QUIZ_H

#include <QDialog>
#include "QTimer"

namespace Ui {
class quiz;
}

class quiz : public QDialog
{
    Q_OBJECT

public:
    explicit quiz(QWidget *parent = nullptr);
    ~quiz();

    //players gets and setters

        QString *getLogo2() const;
        void setLogo2(QString newLogo2);

        QString *getLogo1() const;
        void setLogo1(QString newLogo1);

        QString *getPlayer2() const;
        void setPlayer2(QString newPlayer2);

        QString *getPlayer1() const;
        void setPlayer1(QString newPlayer1);

    private slots:
        //functions that calls each level

        void Level1();void level2();void level3();

        void on_timeBar1_valueChanged(int value);

        void on_quiz_2_clicked();

        void on_timeBar2_valueChanged(int value);

        void on_timeBar3_valueChanged(int value);

        void on_quit_clicked();


private:
        Ui::quiz *ui;
        QString *name1;
        QString *name2;
        QString* logo1;
        QString* logo2;

        //level time and timer to keep track of levels andto separate them
        QTimer* levelT1;QTimer* levelT2;QTimer* levelT3;
        int time1=0;int time2=0;int time3=0;//level time
        int playersTurn;

};

#endif // QUIZ_H
