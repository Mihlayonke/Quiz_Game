#ifndef LEVELTHREE1_H
#define LEVELTHREE1_H

#include "QTimer"
#include <QDialog>

namespace Ui {
class levelThree1;
}

class levelThree1 : public QDialog
{
    Q_OBJECT

public:
    explicit levelThree1(QWidget *parent = nullptr);
    ~levelThree1();
    void setName(QString name,QString logoPlayer);
    void setOpp(QString logoOpp);
private slots:
    void on_answerTime_valueChanged(int value);

    void timeUp();

    void on_nextButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::levelThree1 *ui;
    QTimer* timer;
    int num=0;//chang1
};

#endif // LEVELTHREE1_H
