#include "quiz.h"
#include "ui_quiz.h"
#include "levelthree1.h"
#include "levelthree2.h"
#include "leveltwo1.h"
#include "leveltwo2.h"
#include "player1.h"
#include "player2.h"
#include "QPixmap"

quiz::quiz(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::quiz)
{
    ui->setupUi(this);

    levelT1=new QTimer(this);
    connect(levelT1,SIGNAL(timeout()),this,SLOT(Level1()));
    levelT1->start(1000);
}

quiz::~quiz()
{
    delete ui;
}

void quiz::Level1()
{
    on_timeBar1_valueChanged(time1);
    time1+=1;
    if(time1==100){
        levelT2=new QTimer(this);
        connect(levelT2,SIGNAL(timeout()),this,SLOT(level2()));
        levelT2->start(1000);
    }
}

void quiz::level2()
{
    on_timeBar2_valueChanged(time2);

    if(time2==100){
        levelT3=new QTimer(this);
        connect(levelT3,SIGNAL(timeout()),this,SLOT(level3()));
        levelT3->start(1000);
    }
    time2+=2;
}

void quiz::level3()
{
    on_timeBar3_valueChanged(time3);
    time3+=3;
}

QString *quiz::getLogo2() const
{
    return logo2;
}

void quiz::setLogo2(QString newLogo2)
{
    logo2 = &newLogo2;
    QPixmap pix2=newLogo2;
    int w2=ui->logo2->width();
    int h2=ui->logo2->height();
    ui->logo2->setPixmap(pix2.scaled(w2,h2,Qt::KeepAspectRatio));
}


QString *quiz::getLogo1() const
{
    return logo1;
}

void quiz::setLogo1(QString newLogo1)
{
    logo1 = &newLogo1;

    QPixmap pix1=newLogo1;
    int w1=ui->logo1->width();
    int h1=ui->logo1->height();
    ui->logo1->setPixmap(pix1.scaled(w1,h1,Qt::KeepAspectRatio));
}

QString *quiz::getPlayer2() const
{
    return name2;
}

void quiz::setPlayer2(QString newPlayer2)
{
    name2 = &newPlayer2;
    ui->player2->setText(*name2);
}

QString *quiz::getPlayer1() const
{
    return name1;
}

void quiz::setPlayer1(QString newPlayer1)
{
    name1 = &newPlayer1;
    ui->player1->setText(*name1);
}


void quiz::on_timeBar1_valueChanged(int value)
{
    ui->timeBar1->setValue(value);
}


void quiz::on_quiz_2_clicked()
{
    playersTurn+=1;
    player1 p1;
    player2 p2;
    levelTwo1 lt1;
    leveltwo2 lt2;
    levelThree1 Lthree1;
    levelthree2 Lthree2;

    QString l1=*logo1;
    QString l2=*logo2;

    if(playersTurn%2==0&&time1<101){
        p1.setOpp(l2);
        p1.setName(*name1,l1);
        p1.exec();
        while(p1.isActiveWindow())
            this->hide();
        this->show();
    }

    else if(playersTurn%2!=0&&time1<101){
        p2.setOpp(l1);
        p2.setName(*name2,l2);
        p2.exec();
        while(p2.isActiveWindow())
            this->hide();
        this->show();
    }

    else if(playersTurn%2==0&&time1>100&&time2<101){
        lt1.setOpp(l2);
        lt1.setName(*name1,l1);
        lt1.exec();
        while(lt1.isActiveWindow())
            this->hide();
        this->show();
    }
    else if(playersTurn%2!=0&&time1>100&&time2<101){
        lt2.setOpp(l1);
        lt2.setName(*name2,l2);
        lt2.exec();
        while(lt2.isActiveWindow())
            this->hide();
        this->show();
    }
    else if(playersTurn%2==0&&time2>100&&time3<101){
        Lthree1.setOpp(l2);
        Lthree1.setName(*name1,l1);
        Lthree1.exec();
        while(Lthree1.isActiveWindow())
            this->hide();
        this->show();
    }
    else if(playersTurn%2!=0&&time2>100&&time3<101){
        Lthree2.setOpp(l1);
        Lthree2.setName(*name2,l2);
        Lthree2.exec();
        while(Lthree2.isActiveWindow())
            this->hide();
        this->show();
    }
}


void quiz::on_timeBar2_valueChanged(int value)
{
    ui->timeBar2->setValue(value);
}


void quiz::on_timeBar3_valueChanged(int value)
{
    ui->timeBar3->setValue(value);
}


void quiz::on_quit_clicked()
{
    this->hide();
}


