#ifndef LEVELTHREE2_H
#define LEVELTHREE2_H

#include "QTimer"

#include <QDialog>

namespace Ui {
class levelthree2;
}

class levelthree2 : public QDialog
{
    Q_OBJECT

public:
    explicit levelthree2(QWidget *parent = nullptr);
    ~levelthree2();

    void setName(QString name,QString logoPlayer);
    void setOpp(QString logoOpp);
private slots:
    void on_answerTime_valueChanged(int value);

    void timeUp();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::levelthree2 *ui;
    QTimer* timer;
    int num=0;
};

#endif // LEVELTHREE2_H
